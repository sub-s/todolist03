

const CheckboxItem = (props) => {
    return  (
        <input type="checkbox" />
    )
}

export default CheckboxItem;