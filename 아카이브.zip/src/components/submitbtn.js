

const SubmitBtn = (props) => {
    return  (
        <input type="submit" value={props.title} />
    )
}

export default SubmitBtn;