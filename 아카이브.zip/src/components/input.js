

const InputItem = ({props}) => {
    return  (
        <input type="text" className="fuck" />
    )
}

export default InputItem;